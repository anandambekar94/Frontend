import React, { useState } from "react";
import {
    Box,
    Button,
    Typography,
    Paper,
    Table,
    TableHead,
    TableRow,
    TableCell,
    TableBody,
    LinearProgress,
    Chip,
    TextField,
    Dialog,
    DialogContent,
    IconButton
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import VisibilityIcon from "@mui/icons-material/Visibility";
import Loader from "../common/Loader";

import FilterAltIcon from "@mui/icons-material/FilterAlt";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";

import TopBar from "../common/TopBar";
import { uploadFiles } from "../services/apiService";


const applications = [
    { id: "APP001", applicant: "Vaishnav Logistics", amount: "₹25,00,000", program: "Term Loan", status: "In Progress", progress: 85 },
    { id: "APP002", applicant: "Tech Solutions Inc", amount: "₹50,00,000", program: "Working Capital", status: "Pending", progress: 35 },
    { id: "APP003", applicant: "Manufacturing Co.", amount: "₹1,00,00,000", program: "Equipment Loan", status: "Verified", progress: 55 },
    { id: "APP004", applicant: "Export Business Ltd", amount: "₹75,00,000", program: "LC Limit", status: "In Progress", progress: 10 },
];

const Dashboard: React.FC = () => {
    const [search, setSearch] = useState("");
    const [open, setOpen] = useState(false);
    const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
    const [loading, setLoading] = useState(false); // ✅ loader popup state
    const [errorOpen, setErrorOpen] = useState(false); // ✅ error popup state
    const [errorMessage, setErrorMessage] = useState(""); // ✅ custom error message state

    // ✅ Handle file selection
    const handleFiles = (files: FileList | null) => {
        if (!files) return;
        const validTypes = [
            "application/pdf",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "image/png",
            "image/jpeg",
            "text/html",
            "text/plain",
            "application/vnd.ms-outlook",
        ];
        const filtered = Array.from(files).filter(
            (file) => validTypes.includes(file.type) || file.name.endsWith(".msg")
        );
        const invalidFiles = Array.from(files).some(
            (file) => file.type.startsWith("audio/") || file.type.startsWith("video/")
        );
        if (invalidFiles) {
            setErrorMessage("Audio or video files are not supported. Please upload valid file types.");
            setErrorOpen(true);
            return;
        }
        setSelectedFiles((prev) => [...prev, ...filtered]);
    };

    // ✅ Drag & drop handlers
    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        handleFiles(e.dataTransfer.files);
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
    };

    // ✅ Upload files using service
    const handleUpload = async () => {
        setLoading(true);
        try {
            const result = await uploadFiles(selectedFiles);
            alert(result.message);
            setSelectedFiles([]); // clear after upload
            setOpen(false); // close file dialog
        } catch (error: any) {
            setErrorMessage(error.message);
            setErrorOpen(true);
        } finally {
            setLoading(false); // close loader popup
        }
    };

    const filteredApps = applications.filter(
        (app) =>
            app.applicant.toLowerCase().includes(search.toLowerCase()) ||
            app.id.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <Box sx={{ ml: -4, pt: 0, px: 3, pb: 3 }}>
            <TopBar />

            <Paper sx={{ ml: 4, p: 2, mb: 3 }}>
                <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="h5" fontWeight="bold" color="#d32f2f">
                        Relationship Manager Dashboard
                    </Typography>

                    {/* Open file uploader popup */}
                    <Button variant="contained" color="error" onClick={() => setOpen(true)}>
                        + New Application
                    </Button>
                </Box>
                <Typography variant="body2" color="text.secondary">
                    Manage credit applications and track progress
                </Typography>
            </Paper>

            <Paper sx={{ ml: 4, p: 2 }}>
                {/* 🔎 Search + Filter row */}
                <Box display="flex" alignItems="center" gap={2} mb={2}>
                    <TextField
                        placeholder="Search Applications..."
                        variant="outlined"
                        size="small"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        sx={{ width: "300px" }}
                    />
                    <Button variant="outlined" startIcon={<FilterAltIcon />}>
                        Filter
                    </Button>
                </Box>

                {/* Table */}
                <Box
                    sx={{
                        maxHeight: "400px",
                        overflowY: "auto",
                        msOverflowStyle: "none",
                        scrollbarWidth: "none",
                        "&::-webkit-scrollbar": { display: "none" },
                    }}
                >
                    <Table>
                        <TableHead sx={{ backgroundColor: "#f8f8f8ff" }}>
                            <TableRow>
                                <TableCell sx={{ color: "#d32f2f", fontWeight: 'bold' }}>APPLICATION ID</TableCell>
                                <TableCell sx={{ color: "#d32f2f", fontWeight: 'bold' }}>APPLICANT</TableCell>
                                <TableCell sx={{ color: "#d32f2f", fontWeight: 'bold' }}>AMOUNT</TableCell>
                                <TableCell sx={{ color: "#d32f2f", fontWeight: 'bold' }}>PROGRAM</TableCell>
                                <TableCell sx={{ color: "#d32f2f", fontWeight: 'bold' }}>STATUS</TableCell>
                                <TableCell sx={{ color: "#d32f2f", fontWeight: 'bold' }}>PROGRESS</TableCell>
                                <TableCell sx={{ color: "#d32f2f", fontWeight: 'bold' }}>ACTIONS</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {filteredApps.map((app) => (
                                <TableRow key={app.id}>
                                    <TableCell>{app.id}</TableCell>
                                    <TableCell sx={{ color: "#0b8ff4ff" }}>{app.applicant}</TableCell>
                                    <TableCell>{app.amount}</TableCell>
                                    <TableCell>
                                        <Chip label={app.program} color="secondary" variant="outlined" />
                                    </TableCell>
                                    <TableCell>
                                        <Chip
                                            label={app.status}
                                            color={
                                                app.status === "Verified"
                                                    ? "success"
                                                    : app.status === "Pending"
                                                        ? "warning"
                                                        : "info"
                                            }
                                        />
                                    </TableCell>
                                    <TableCell>
                                        <Box display="flex" alignItems="center" gap={1}>
                                            <LinearProgress
                                                variant="determinate"
                                                value={app.progress}
                                                sx={{ flex: 1, height: 8, borderRadius: 5 }}
                                            />
                                            <Typography variant="body2">{app.progress}%</Typography>
                                        </Box>
                                    </TableCell>
                                    <TableCell>
                                        <IconButton color="primary" title="View">
                                            <VisibilityIcon />
                                        </IconButton>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </Box>
            </Paper>

            {/* 📂 File Uploader Popup */}
            <Dialog open={open} onClose={() => setOpen(false)} maxWidth="md" fullWidth>
                {/* Dialog Title with Close (X) button */}
                <Box
                    sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        px: 2,
                        pt: 1,
                    }}
                >
                    <Box flex={1} textAlign="center">
                        <Typography variant="h5" fontWeight="bold" color="error" sx={{ fontSize: "1.6rem" }}>
                            Intelligent Credit Appraisal Assistant
                        </Typography>
                        <Typography variant="body1" color="text.secondary" mt={1}>
                            Upload your documents to begin the intelligent credit assessment process
                        </Typography>
                    </Box>

                    <IconButton onClick={() => setOpen(false)} sx={{ color: "gray", position: "absolute", right: 16, top: 16 }}>
                        <CloseIcon />
                    </IconButton>
                </Box>

                <DialogContent>
                    <Box textAlign="center" p={3} mt={-5}>
                        {/* Drag-drop box */}
                        <Box
                            onDrop={handleDrop}
                            onDragOver={handleDragOver}
                            sx={{
                                border: "2px dashed #ccc",
                                borderRadius: 2,
                                p: 5,
                                my: 3,
                                textAlign: "center",
                                cursor: "pointer",
                            }}
                        >
                            <CloudUploadIcon sx={{ fontSize: 40, color: "gray", mb: 1 }} />
                            <Typography variant="body2" color="text.secondary">
                                Drag your files here or click to browse
                            </Typography>

                            {/* Hidden File Input */}
                            <input
                                id="file-input"
                                type="file"
                                multiple
                                accept=".pdf,.xlsx,.xls,.docx,.png,.jpg,.jpeg,.html,.txt,.msg"
                                style={{ display: "none" }}
                                onChange={(e) => handleFiles(e.target.files)}
                            />

                            <label htmlFor="file-input">
                                <Button
                                    variant="contained"
                                    color="error"
                                    component="span"
                                    sx={{ mt: 2 }}
                                >
                                    Choose Files
                                </Button>
                            </label>

                            {/* Show Upload Button + File list if files selected */}
                            {selectedFiles.length > 0 && (
                                <Box mt={3}>
                                    <Typography variant="body2" color="text.secondary" gutterBottom>
                                        {selectedFiles.length} file(s) selected
                                    </Typography>

                                    <Button
                                        variant="contained"
                                        color="success"
                                        sx={{ mt: 2 }}
                                        onClick={handleUpload}
                                    >
                                        Upload
                                    </Button>
                                </Box>
                            )}
                        </Box>

                        {/* Steps row */}
                        <Box display="flex" justifyContent="center" gap={4} mt={5}>
                            <Paper sx={{ p: 3, textAlign: "center", width: "28%", borderRadius: "16px" }}>
                                {/* Circle number */}
                                <Box
                                    sx={{
                                        width: 48,
                                        height: 48,
                                        borderRadius: "50%",
                                        backgroundColor: "error.main",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        mx: "auto",
                                        mb: 2,
                                    }}
                                >
                                    <Typography variant="body1" fontWeight="bold" color="white">
                                        1
                                    </Typography>
                                </Box>

                                <Typography variant="subtitle1" fontWeight="bold">Upload Docs</Typography>
                                <Typography variant="body2" color="text.secondary">Drag & drop documents</Typography>
                            </Paper>

                            <Paper sx={{ p: 3, textAlign: "center", width: "28%", borderRadius: "16px" }}>
                                <Box
                                    sx={{
                                        width: 48,
                                        height: 48,
                                        borderRadius: "50%",
                                        backgroundColor: "error.main",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        mx: "auto",
                                        mb: 2,
                                    }}
                                >
                                    <Typography variant="body1" fontWeight="bold" color="white">
                                        2
                                    </Typography>
                                </Box>

                                <Typography variant="subtitle1" fontWeight="bold">AI Analysis</Typography>
                                <Typography variant="body2" color="text.secondary">Intelligent Processing</Typography>
                            </Paper>

                            <Paper sx={{ p: 3, textAlign: "center", width: "28%", borderRadius: "16px" }}>
                                <Box
                                    sx={{
                                        width: 48,
                                        height: 48,
                                        borderRadius: "50%",
                                        backgroundColor: "error.main",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        mx: "auto",
                                        mb: 2,
                                    }}
                                >
                                    <Typography variant="body1" fontWeight="bold" color="white">
                                        3
                                    </Typography>
                                </Box>

                                <Typography variant="subtitle1" fontWeight="bold">Generate CAM</Typography>
                                <Typography variant="body2" color="text.secondary">Automated reports</Typography>
                            </Paper>
                        </Box>

                    </Box>
                </DialogContent>
            </Dialog>
            <Loader open={loading} />
            {/* Error Popup */}
            <Dialog open={errorOpen} onClose={() => setErrorOpen(false)}>
                <Box sx={{ p: 3, textAlign: "center" }}>
                    <Typography variant="h6" color="error">
                        Upload Error
                    </Typography>
                    <Typography variant="body2" color="text.secondary" mt={2}>
                        {errorMessage}
                    </Typography>
                    <Button
                        variant="contained"
                        color="error"
                        sx={{ mt: 3 }}
                        onClick={() => setErrorOpen(false)}
                    >
                        Close
                    </Button>
                </Box>
            </Dialog>
        </Box>
    );
};

export default Dashboard;