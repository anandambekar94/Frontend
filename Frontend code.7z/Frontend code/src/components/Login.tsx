import React, { useState } from "react";
import {
    Box,
    Button,
    Container,
    TextField,
    Typography,
    Paper,
    Snackbar,
    Alert,
} from "@mui/material";
import { useNavigate } from "react-router-dom";

const Login: React.FC = () => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();

        // Demo credentials
        if (username === "admin" && password === "1234") {
            localStorage.setItem("isLoggedIn", "true");
            localStorage.setItem("username", username);
            navigate("/dashboard");
        } else {
            setError(true);
        }
    };

    return (
        <Box
            sx={{
                height: "100vh",
                width: "100%",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                backgroundColor: "#fafafa",
                position: "fixed",
                top: 0,
                left: 0,
            }}
        >
            <Container maxWidth="sm" disableGutters>
                <Paper
                    elevation={4}
                    sx={{
                        p: 5,
                        borderRadius: 4,
                        boxSizing: "border-box",
                        textAlign: "center",
                    }}
                >
                    {/* ✅ Logo */}
                    <Box mb={2}>
                        <img
                            src="src\assets\images\abc_logo.png" // replace with your actual logo path
                            //alt="Company Logo"
                            style={{ height: 60 }}
                        />
                    </Box>

                    {/* ✅ Heading */}
                    <Typography
                        variant="h5"
                        fontWeight="bold"
                        gutterBottom
                        sx={{ color: "#d32f2f" }}
                    >
                        CAM - Login
                    </Typography>
                    <Typography variant="body2" color="text.secondary" mb={3}>
                        Sign in to continue to your dashboard
                    </Typography>

                    {/* ✅ Form */}
                    <Box component="form" onSubmit={handleSubmit}>
                        <TextField
                            label="Username"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                        />
                        <TextField
                            label="Password"
                            type="password"
                            variant="outlined"
                            fullWidth
                            margin="normal"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                        />
                        <Button
                            type="submit"
                            variant="contained"
                            color="error"
                            sx={{
                                mt: 3,
                                py: 1.2,
                                px: 5,                // padding for a wider feel
                                fontWeight: "bold",
                                borderRadius: 2,
                                textTransform: "none",
                                width: "60%",         // ✅ reduce width (try 50–70%)
                                mx: "auto",           // ✅ center align horizontally
                                display: "block",     // required for mx:auto to work
                            }}
                        >
                            Login
                        </Button>

                    </Box>
                </Paper>

                {/* ✅ Error Snackbar */}
                <Snackbar
                    open={error}
                    autoHideDuration={3000}
                    onClose={() => setError(false)}
                    anchorOrigin={{ vertical: "top", horizontal: "center" }}
                >
                    <Alert
                        severity="error"
                        onClose={() => setError(false)}
                        sx={{ width: "100%" }}
                    >
                        Invalid credentials!
                    </Alert>
                </Snackbar>
            </Container>
        </Box>
    );
};

export default Login;
