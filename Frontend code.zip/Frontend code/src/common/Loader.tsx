import React from "react";
import {
    Dialog,
    DialogContent,
    Box,
    Typography,
    CircularProgress
} from "@mui/material";

interface LoaderPopupProps {
    open: boolean;
}

const LoaderPopup: React.FC<LoaderPopupProps> = ({ open }) => {
    return (
        <Dialog open={open} maxWidth="sm" fullWidth sx={{ borderRadius: "16px" }}>
            <DialogContent>
                <Box
                    display="flex"
                    flexDirection="column"
                    alignItems="center"
                    justifyContent="center"
                    p={4}
                    textAlign="center"

                >
                    {/* Circular Loader */}
                    <CircularProgress
                        size={70}
                        thickness={4}
                        sx={{ color: "error.main", mb: 3 }}
                    />

                    {/* Title */}
                    <Typography
                        variant="h6"
                        fontWeight="bold"
                        color="error"
                        gutterBottom
                    >
                        Uploading Documents
                    </Typography>

                    {/* Subtext */}
                    <Typography variant="body2" color="text.secondary" mb={3}>
                        Please wait, documents are uploading...
                    </Typography>

                    {/* Progress bar */}
                    {/* <LinearProgress
                        variant="indeterminate"
                        sx={{ width: "100%", height: 8, borderRadius: 5 }}
                        color="error"
                    /> */}
                </Box>
            </DialogContent>
        </Dialog>
    );
};

export default LoaderPopup;
