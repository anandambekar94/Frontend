import { Box, Menu, MenuItem, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import AccountCircle from "@mui/icons-material/AccountCircle";
import ArrowDropDown from "@mui/icons-material/ArrowDropDown";

const TopBar: React.FC = () => {
    const navigate = useNavigate();
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const open = Boolean(anchorEl);
    const username = localStorage.getItem("username") || "User";

    const handleMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };

    const handleMenuClose = () => {
        setAnchorEl(null);
    };

    const handleLogout = () => {
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("username");
        handleMenuClose();
        navigate("/");
    };

    return (
        <Box sx={{ 
            mt: 0, 
            py: 1,  // Reduced from 1 (adds ~16px vertical padding instead of 32px)
            px: 2,
            mb: 2,    // Reduced from 3 (less bottom margin after the bar)
            width: '100%',
            backgroundColor: 'white',
            borderBottom: '1px solid #e0e0e0'
        }}>
            <Box
                sx={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    mb: 0.5,  // Reduced from 2 (adds ~8px instead of 16px)
                }}
            >
                {/* Logo on the left */}
                <Box
                    component="img"
                    src="src\assets\images\abc_logo.png"
                    alt="Aditya Birla Capital"
                    sx={{
                        width: 32,  // Reduced from 40 for a more compact look
                        height: 32,
                        ml: 2,      // Reduced from 4 to tighten left spacing
                    }}
                />

                {/* Profile section on the right */}
                <Box
                    sx={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 0.5,   // Reduced from 1 for tighter gaps
                        cursor: 'pointer',
                    }}
                    onClick={handleMenuOpen}
                >
                    <AccountCircle sx={{ fontSize: 24 }} />  {/* Reduced from 30 */}
                    <Typography 
                        variant="body2"  // Switched to body2 for smaller font (~14px vs 16px)
                        sx={{ fontSize: '0.875rem' }}  // Explicitly smaller if needed
                    >
                        {username}
                    </Typography>
                    <ArrowDropDown sx={{ fontSize: 20 }} />  {/* Added size for consistency */}
                </Box>

                {/* Dropdown menu */}
                <Menu
                    anchorEl={anchorEl}
                    open={open}
                    onClose={handleMenuClose}
                    anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'right',
                    }}
                    transformOrigin={{
                        vertical: 'top',
                        horizontal: 'right',
                    }}
                >
                    <MenuItem onClick={handleLogout}>Logout</MenuItem>
                </Menu>
            </Box>
        </Box>
    );
};

export default TopBar;