

export const uploadFiles = async (files: File[]) => {
    const formData = new FormData();
    files.forEach((file) => {
        formData.append(`file`, file);
    });

    try {
        const response = await fetch("http://127.0.0.1:8000/upload_files", {
            method: "POST",
            body: formData,
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || "Failed to upload files. Please try again.");
        }

        return { success: true, message: `${files.length} file(s) uploaded successfully!` };
    } catch (error: any) {
        throw new Error("Connection error: Unable to reach the server. Please check your network and try again.");
    }
};